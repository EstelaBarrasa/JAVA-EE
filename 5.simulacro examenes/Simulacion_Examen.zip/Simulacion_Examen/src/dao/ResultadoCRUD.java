package dao;

public enum ResultadoCRUD {
	OK,ERROR,YA_EXISTE
}
