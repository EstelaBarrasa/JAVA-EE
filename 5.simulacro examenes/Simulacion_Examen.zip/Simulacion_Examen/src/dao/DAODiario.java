package dao;

import java.io.IOException;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db.DB;
import modelo.diario;

public class DAODiario implements Serializable {

	public static final long serialVersionUID=1L;
	
	public diario getDiario(String nombre_usuario, Date fecha, String texto){
		diario d=null;
		
		String sql="Select * from texto order by fecha asc";
		try(Connection con=DB.getConexion();
				Statement st=con.createStatement()){
				
				ResultSet rs=st.executeQuery(sql);
				while(rs.next()){
					diario d=new diario(rs.getString("nombre"),rs.getString("contrase�a")rs.getString("nombre_usuario"),rs.getDate("fecha"),rs.getString("texto"));
					lista.add(d);
				}
					
			}
			catch (SQLException sqle){
				sqle.printStackTrace();
			}
			
			return lista;
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		  request.getRequestDispatcher("ServletListado").forward(request, response); 
	}

}
