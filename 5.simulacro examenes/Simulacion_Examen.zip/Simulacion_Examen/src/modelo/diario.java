package modelo;

import java.io.Serializable;
import java.util.Date;

public class diario implements Serializable{
	public static final long serialVersionUID=1L;
	

	private String nombre;
	private String contrase�a;
	private String nombre_usuario;
	private Date fecha; 
	private String texto;
	
	
	public diario(){
		
	}
	
	public diario(String nombre,String contrase�a,String nombre_usuario, Date fecha, String texto){
		this.nombre_usuario=nombre_usuario;
		this.fecha=fecha;
		this.texto=texto;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getContrase�a() {
		return contrase�a;
	}

	public void setContrase�a(String contrase�a) {
		this.contrase�a = contrase�a;
	}

	public String getNombre_usuario() {
		return nombre_usuario;
	}

	public void setNombre_usuario(String nombre_usuario) {
		this.nombre_usuario = nombre_usuario;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}
	

}
	
	